(function () {
  const data = window.DASHBOARD_DATA;
  if (!data) return;
  const palette = ["#386d5b", "#d79a3d", "#7d8b62", "#bd6f4b", "#74959a", "#c4b18b"];
  const fmt = new Intl.NumberFormat("en-US");

  const put = (id, value) => {
    const el = document.getElementById(id);
    if (el) el.textContent = value;
  };
  const svgEl = (tag, attrs = {}) => {
    const el = document.createElementNS("http://www.w3.org/2000/svg", tag);
    Object.entries(attrs).forEach(([key, value]) => el.setAttribute(key, value));
    return el;
  };

  function renderBars(id, items, options = {}) {
    const host = document.getElementById(id);
    if (!host) return;
    const width = 760;
    const left = options.left || 230;
    const rowHeight = options.rowHeight || 38;
    const top = 14;
    const height = top + rowHeight * items.length + 10;
    const max = Math.max(...items.map((d) => d.value), 1);
    const plotWidth = width - left - 64;
    const svg = svgEl("svg", { viewBox: `0 0 ${width} ${height}`, role: "img", "aria-label": options.aria || "Bar chart" });
    items.forEach((item, i) => {
      const y = top + i * rowHeight;
      const label = svgEl("text", { x: left - 14, y: y + 19, "text-anchor": "end", class: "chart-label" });
      label.textContent = item.label;
      svg.append(label);
      const barWidth = Math.max(2, (item.value / max) * plotWidth);
      const bar = svgEl("rect", { x: left, y: y + 3, width: barWidth, height: 22, rx: 5, fill: item.color || palette[i % palette.length], class: "chart-bar" });
      const title = svgEl("title");
      title.textContent = `${item.label}: ${fmt.format(item.value)}`;
      bar.append(title);
      svg.append(bar);
      const value = svgEl("text", { x: Math.min(width - 8, left + barWidth + 9), y: y + 19, class: "chart-value" });
      value.textContent = fmt.format(item.value);
      svg.append(value);
    });
    host.replaceChildren(svg);
  }

  function renderDonut(id, legendId, items, centerLabel) {
    const host = document.getElementById(id);
    const legend = document.getElementById(legendId);
    if (!host || !legend) return;
    const total = items.reduce((sum, item) => sum + item.value, 0);
    const radius = 72;
    const circumference = 2 * Math.PI * radius;
    const svg = svgEl("svg", { viewBox: "0 0 220 220", role: "img", "aria-label": `${centerLabel}, ${fmt.format(total)} total` });
    svg.append(svgEl("circle", { cx: 110, cy: 110, r: radius, fill: "none", stroke: "#e8e5dc", "stroke-width": 28 }));
    let offset = 0;
    items.forEach((item, index) => {
      const length = total ? (item.value / total) * circumference : 0;
      const circle = svgEl("circle", {
        cx: 110, cy: 110, r: radius, fill: "none", stroke: item.color || palette[index % palette.length],
        "stroke-width": 28, "stroke-dasharray": `${length} ${circumference - length}`,
        "stroke-dashoffset": `${-offset}`, transform: "rotate(-90 110 110)"
      });
      const title = svgEl("title");
      title.textContent = `${item.label}: ${fmt.format(item.value)} (${total ? ((item.value / total) * 100).toFixed(1) : "0.0"}%)`;
      circle.append(title);
      svg.append(circle);
      offset += length;
    });
    const center = svgEl("text", { x: 110, y: 106, "text-anchor": "middle", class: "donut-total" });
    center.textContent = fmt.format(total);
    const caption = svgEl("text", { x: 110, y: 128, "text-anchor": "middle", class: "donut-caption" });
    caption.textContent = centerLabel;
    svg.append(center, caption);
    host.replaceChildren(svg);
    legend.replaceChildren(...items.map((item, index) => {
      const li = document.createElement("li");
      const swatch = document.createElement("span");
      swatch.className = "legend-swatch";
      swatch.style.backgroundColor = item.color || palette[index % palette.length];
      const name = document.createElement("span");
      name.textContent = item.label;
      const count = document.createElement("strong");
      count.textContent = `${fmt.format(item.value)} · ${total ? ((item.value / total) * 100).toFixed(1) : "0.0"}%`;
      li.append(swatch, name, count);
      return li;
    }));
  }

  function renderCoverage() {
    const host = document.getElementById("coverage-list");
    if (!host) return;
    host.replaceChildren(...data.numericCoverage.map((item) => {
      const row = document.createElement("div");
      row.className = "coverage-row";
      const header = document.createElement("div");
      header.className = "coverage-meta";
      const label = document.createElement("span"); label.textContent = item.label;
      const value = document.createElement("strong");
      const percent = (item.value / data.sourceRows) * 100;
      value.textContent = `${fmt.format(item.value)} · ${percent.toFixed(1)}%`;
      header.append(label, value);
      const track = document.createElement("div"); track.className = "coverage-track";
      const fill = document.createElement("span"); fill.style.width = `${percent}%`;
      track.append(fill); row.append(header, track);
      return row;
    }));
  }

  put("source-rows", fmt.format(data.sourceRows));
  put("unique-records", fmt.format(data.uniqueExactRecords));
  put("repeated-rows", fmt.format(data.repeatedRowsGrouped));
  put("distinct-titles", fmt.format(data.distinctCleanTitles));
  put("average-rating", data.averageRating.toFixed(2));
  put("median-price", `$${data.medianCurrentPrice.toFixed(2)}`);
  put("sales-coverage", `${((data.numericSalesRows / data.sourceRows) * 100).toFixed(1)}%`);
  put("price-coverage", `${((data.currentPriceRows / data.sourceRows) * 100).toFixed(1)}%`);
  put("title-clean-count", fmt.format(data.titleRowsChanged));

  renderBars("rating-chart", data.ratings, { aria: "Rating bands among unique exact records" });
  renderDonut("sponsorship-chart", "sponsorship-legend", data.sponsorship, "records");
  renderDonut("coupon-chart", "coupon-legend", data.coupons, "records");
  renderBars("price-chart", data.prices, { aria: "Current price bands, including missing prices" });
  renderBars("coverage-chart", data.numericCoverage, { aria: "Numeric field coverage across source rows", left: 205 });
  renderBars("badge-chart", data.badgeDeals, { aria: "Badge and deal categories among unique exact records", left: 260 });
  renderCoverage();
})();
