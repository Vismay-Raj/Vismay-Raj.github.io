# Data analytics portfolio site

A small static portfolio site with an aggregate interactive dashboard for the Amazon listings analysis. It uses plain HTML, CSS, and JavaScript and can be hosted on GitHub Pages.

## Personalize it

Edit `site-config.js` to set the display name, initials, tagline, email, GitHub, and LinkedIn links. Leave a link empty to hide it. Replace the project details in `index.html` as you add work.

## Dashboard data

`dashboard-data.js` contains aggregate counts only. The raw workbook and row-level data are not included in this site folder. The dashboard groups exact repeated records only; it does not claim to identify distinct products.

## Publish with GitHub Pages

For the free GitHub Pages subdomain, use a public repository. A personal site repository is named `<your-github-username>.github.io`; put these site files at the repository root. In the repository, open **Settings → Pages**, select **Deploy from a branch**, and choose the `main` branch and `/ (root)`. GitHub Pages will publish the static files at `https://<your-github-username>.github.io/`.

GitHub Pages is static hosting, so the dashboard is a snapshot. Update `dashboard-data.js` and the site files when the underlying analysis changes.
