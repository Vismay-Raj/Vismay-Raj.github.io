/* Edit these values to personalize the portfolio. Leave a link empty to hide it. */
window.PORTFOLIO_CONFIG = {
  name: "Your Name",
  initials: "YN",
  tagline: "Turning raw data into clear, careful analysis.",
  email: "",
  github: "",
  linkedin: ""
};
