/* Aggregate values only. No source rows or individual product titles are published here. */
window.DASHBOARD_DATA = {
  sourceRows: 42675,
  uniqueExactRecords: 9533,
  repeatedRowsGrouped: 33142,
  distinctCleanTitles: 8034,
  titleRowsChanged: 35,
  averageRating: 4.441014799154334,
  medianCurrentPrice: 69.99,
  numericSalesRows: 35381,
  salesTextRows: 7294,
  currentPriceRows: 30926,
  currentPriceMissingRows: 11749,
  ratings: [
    { label: "1.0–2.9", value: 21 },
    { label: "3.0–3.9", value: 524 },
    { label: "4.0–4.4", value: 3671 },
    { label: "4.5–4.9", value: 5107 },
    { label: "5.0", value: 137 },
    { label: "No rating", value: 73 }
  ],
  sponsorship: [
    { label: "Organic", value: 8980, color: "#4f7d67" },
    { label: "Sponsored", value: 553, color: "#d79a3d" }
  ],
  coupons: [
    { label: "No coupon", value: 9298, color: "#4f7d67" },
    { label: "Coupon offer", value: 235, color: "#d79a3d" }
  ],
  prices: [
    { label: "Under $25", value: 1646 },
    { label: "$25–$49.99", value: 1195 },
    { label: "$50–$99.99", value: 1071 },
    { label: "$100–$249.99", value: 1520 },
    { label: "$250+", value: 1157 },
    { label: "Missing current price", value: 2944 }
  ],
  numericCoverage: [
    { label: "Rating", value: 41651 },
    { label: "Review count", value: 41651 },
    { label: "Last-month sales", value: 35381 },
    { label: "Current price", value: 30926 },
    { label: "Explicit variant price", value: 19825 },
    { label: "Listed price", value: 12311 }
  ],
  badgeDeals: [
    { label: "No Badge", value: 8956 },
    { label: "Best Seller", value: 220 },
    { label: "Amazon badge text (incomplete)", value: 319 },
    { label: "Limited-time deal", value: 27 },
    { label: "Discount text", value: 9 },
    { label: "Countdown text (incomplete)", value: 2 }
  ]
};
