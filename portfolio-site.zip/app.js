(function () {
  const config = window.PORTFOLIO_CONFIG || {};
  document.querySelectorAll("[data-site-name]").forEach((el) => { el.textContent = config.name || "Your Name"; });
  document.querySelectorAll("[data-initials]").forEach((el) => { el.textContent = config.initials || "YN"; });
  document.querySelectorAll("[data-tagline]").forEach((el) => { el.textContent = config.tagline || "Turning raw data into clear, careful analysis."; });
  document.querySelectorAll("[data-year]").forEach((el) => { el.textContent = new Date().getFullYear(); });

  const links = [
    ["github", config.github],
    ["linkedin", config.linkedin],
    ["email", config.email ? `mailto:${config.email}` : ""]
  ];
  links.forEach(([name, href]) => {
    document.querySelectorAll(`[data-contact="${name}"]`).forEach((el) => {
      if (href) {
        el.href = href;
        el.hidden = false;
        if (name !== "email") { el.target = "_blank"; el.rel = "noreferrer"; }
      } else {
        el.hidden = true;
      }
    });
  });

  const toggle = document.querySelector(".menu-toggle");
  const nav = document.querySelector(".primary-nav");
  if (toggle && nav) {
    toggle.addEventListener("click", () => {
      const open = toggle.getAttribute("aria-expanded") === "true";
      toggle.setAttribute("aria-expanded", String(!open));
      nav.classList.toggle("is-open", !open);
    });
  }
})();
